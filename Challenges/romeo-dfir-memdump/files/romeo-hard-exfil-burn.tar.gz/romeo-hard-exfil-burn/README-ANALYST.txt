================================================================================
  EVERSEC INCIDENT RESPONSE — CASE #2026-0417
  Operation Midnight Raven — Day 3: "Exfil and Burn"
  Host: WS-FINANCE-01 (10.10.15.103)
  Analyst: M. Chen | Capture Time: 2026-03-17 09:15:00 UTC
================================================================================

SITUATION REPORT:
This is the final system compromised in the Operation Midnight Raven campaign.
WS-FINANCE-01 belongs to a senior financial analyst with access to quarterly
earnings reports, M&A documents, and payroll data.

The threat actor appears to have staged data for exfiltration and attempted
to cover their tracks using anti-forensics techniques. Memory was captured
before the attacker could fully clean up.

Volatility 3 plugins executed against the raw image:

  vol3-pslist.txt       Process listing
  vol3-pstree.txt       Process tree
  vol3-netscan.txt      Network connections
  vol3-malfind.txt      Injected code detection (suspicious memory regions)
  vol3-timeliner.txt    Combined timeline of system activity
  vol3-mftparser.txt    MFT (Master File Table) entries

Extracted artifacts:
  extracted/staging/data.b64         Base64 blob found in attacker staging dir
  extracted/dns_queries.pcap.txt     DNS query log from packet capture

YOUR OBJECTIVES:
  1. Analyze injected code regions — decode any obfuscated payloads
  2. Recover staged exfiltration data
  3. Detect anti-forensics activity (timestamp manipulation)
  4. Reconstruct covert data exfiltration channels

ANALYST NOTES:
  - The malfind output shows suspicious memory regions. The attacker uses
    single-byte XOR encoding (key unknown) on sensitive strings.
  - A base64 blob was recovered from C:\Users\j.park\AppData\Local\Temp\staging\
  - DNS logs show unusual query patterns to a subdomain of exfil.midnightraven.net
  - Some file timestamps don't add up — compare timeliner and MFT data carefully

Submit flag values discovered during your analysis.
Good hunting.
