================================================================================
  EVERSEC INCIDENT RESPONSE — CASE #2026-0417
  Operation Midnight Raven — Day 2: "Lateral Move"
  Host: WS-DEVOPS-01 (10.10.15.77)
  Analyst: M. Chen | Capture Time: 2026-03-16 11:42:00 UTC
================================================================================

SITUATION REPORT:
After the Day 1 phishing compromise on WS-RECEPTION-01, the threat actor
appears to have moved laterally to WS-DEVOPS-01 (a DevOps engineer's
workstation). This machine has elevated network access and stored credentials.

Memory was captured at 11:42 UTC. The following Volatility 3 plugins were
executed against the raw image and their output is included in this archive:

  vol3-pslist.txt       Process listing
  vol3-pstree.txt       Process tree (parent/child relationships)
  vol3-cmdline.txt      Command-line arguments for all processes
  vol3-netscan.txt      Network connections and listening sockets
  vol3-printkey.txt     Registry key enumeration

Additionally, the following artifacts were extracted:
  extracted/scheduled_task.xml    Suspicious scheduled task found in memory
  extracted/lsass_strings.txt     Strings extracted from LSASS process memory

An IOC list from our threat intel feed is included:
  analyst-ioc-notes.txt

YOUR OBJECTIVES:
  1. Identify anomalous network connections and correlate with known threat intel
  2. Analyze persistence mechanisms installed by the attacker
  3. Examine registry modifications for autorun entries
  4. Review extracted credential material for compromised accounts

Submit flag values discovered during your analysis.
Good hunting.
